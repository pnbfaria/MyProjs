(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0jn8.0u.css","static/chunks/node_modules_0_h8..r._.js","static/chunks/components_layout_Sidebar_tsx_0l97vef._.js"],
    source: "dynamic"
});
